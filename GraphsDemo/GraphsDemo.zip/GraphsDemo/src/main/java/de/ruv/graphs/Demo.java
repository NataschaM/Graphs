package de.ruv.graphs;

import java.util.List;
import java.util.Set;

import org.jgrapht.DirectedGraph;
import org.jgrapht.alg.DijkstraShortestPath;
import org.jgrapht.alg.DirectedNeighborIndex;
import org.jgrapht.event.GraphVertexChangeEvent;
import org.jgrapht.graph.DefaultDirectedGraph;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.graph.ListenableDirectedWeightedGraph;
import org.jgrapht.graph.SimpleDirectedGraph;
import org.jgrapht.graph.SimpleDirectedWeightedGraph;

public class Demo {

	public static void main(String[] args) {
		
		ListenableDirectedWeightedGraph<String, DefaultWeightedEdge> g =
         new ListenableDirectedWeightedGraph<String, DefaultWeightedEdge>
         (DefaultWeightedEdge.class);
     g.addVertex("a");
     g.addVertex("b");
     g.addVertex("c");
     g.addVertex("d");
     g.addVertex("e");
     g.addVertex("f");
     g.addVertex("g");
     g.addVertex("h");
     g.addVertex("i");
     g.setEdgeWeight(g.addEdge("a", "b"), 1);
     g.setEdgeWeight(g.addEdge("b", "d"), 1);
     g.setEdgeWeight(g.addEdge("d", "c"), 1);
     g.setEdgeWeight(g.addEdge("c", "a"), 1);
     g.setEdgeWeight(g.addEdge("e", "d"), 1);
     g.setEdgeWeight(g.addEdge("e", "f"), 1);
     g.setEdgeWeight(g.addEdge("f", "g"), 1);
     g.setEdgeWeight(g.addEdge("g", "e"), 1);
     g.setEdgeWeight(g.addEdge("h", "e"), 1);
     g.setEdgeWeight( g.addEdge("i", "h"), 1);
     g.setEdgeWeight(g.addEdge("e", "a"), 1000);
     
     System.out.println("Shortest path from i to c:");
     List path =
         DijkstraShortestPath.findPathBetween(g, "g", "a");
     System.out.println(path + "\n");
     
    DirectedNeighborIndex<String, DefaultWeightedEdge> indexer = new DirectedNeighborIndex<String, DefaultWeightedEdge>(g);
   	g.addVertexSetListener(indexer);
   	
   	Set<String> vertices = indexer.predecessorsOf("c");
    
    for(String vertex : vertices) {
   	 System.out.println(vertex);
    }
     
     g.removeVertex("c");
     path =
         DijkstraShortestPath.findPathBetween(g, "g", "a");
     System.out.println(path + "\n");
     
    vertices = indexer.predecessorsOf("c");
     
     for(String vertex : vertices) {
    	 System.out.println(vertex);
     }
//     indexer.vertexRemoved(new GraphVertexChangeEvent(g, GraphVertexChangeEvent.VERTEX_REMOVED, "c"));
     
     g.addVertex("c");
//     indexer.vertexAdded(new GraphVertexChangeEvent(g, GraphVertexChangeEvent.VERTEX_ADDED, "c"));
     
     path =
         DijkstraShortestPath.findPathBetween(g, "g", "a");
     System.out.println(path + "\n");

	}

}
